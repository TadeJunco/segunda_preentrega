
class Clientes():
    def __init__ (self, nombre, producto, dni, email):
        self.nombre = nombre
        self.producto = producto
        self.dni = dni
        self.email = email
        base_De_Datos[email] = producto
        
        
    
    def cambiar_email(self, nuevo_email):
        self.nuevo_email = nuevo_email
        print(f"el nuevo correo de {self.nombre} es {self.nuevo_email}")
        self.email = nuevo_email
        
        


             
    def cambiar_producto(self, cambiar_producto):
            self.cambiar_producto = cambiar_producto
            input("¿Por que quiere cambiar el producto? \n")
            print(f"Gracias por la explicacion, cambiamos su {self.producto}, por su {self.cambiar_producto}")
            self.producto =  cambiar_producto
            
        
    def __str__(self):
        return f"la info del cliente es: {self.nombre} \n su producto: {self.producto} \n dni: {self.dni} \n email: {self.email}"

        
        
        
base_De_Datos = {}
for dato in base_De_Datos:
    print(dato)


     
































