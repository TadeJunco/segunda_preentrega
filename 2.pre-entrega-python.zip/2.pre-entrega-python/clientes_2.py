from clientes import Clientes

from clientes import base_De_Datos


cliente_1 = Clientes("tadeo", "celular", "44927895", "tade@junco")

cliente_2 = Clientes ("abril", "tablet", "4244978", "abril@sosa")

cliente_3 = Clientes ("betina","paleta", "3080890", "betina@gmail.com")
        
print (cliente_1,cliente_2, cliente_3)

print(cliente_1)
print(base_De_Datos)


cliente_1.cambiar_email("tade.junco@")




print(cliente_1)



 
 















    